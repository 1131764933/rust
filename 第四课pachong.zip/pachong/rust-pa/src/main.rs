use scraper::{Html, Selector};
use std::error::Error;
use ego_tree::{NodeRef,*};
// use select::document::Document;
use tokio;
use reqwest;
#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    // 1. 发送 GET 请求获取 rust.cn 日报首页内容
    let response = reqwest::get("https://rust.cc/").await?.text().await?;
    // 2. 解析 HTML，提取文章列表
    let document = Html::parse_document(&response);
    let article_selector = Selector::parse(".post-title > a").unwrap();
    let date_selector = Selector::parse(".post-meta").unwrap();
    let mut articles = vec![];
    for (i, element) in document.select(&article_selector).enumerate() {
        if i == 10 {
            break;
        }
        let title = element.inner_html();
        let date_element = element
            .parent()
            .unwrap()
            .select(&date_selector)
            .next()
            .unwrap();
        let date = date_element.inner_html();
        articles.push((date, title));
    }
    // 3. 按照时间顺序排序
    articles.sort_by_key(|(date, _)| date.to_owned());
    // 4. 输出标题列表
    for (i, (date, title)) in articles.iter().enumerate() {
        println!("{}. {} ({})", i + 1, title, date);
    }
    Ok(())
}

