use select::document::Document;
use select::predicate::{Name, Class};
use chrono::prelude::*;
use reqwest::blocking::get;

fn main() {
    let url = "https://rustcc.cn/";
    let html = get(url).unwrap().text().unwrap();
    let document = Document::from(html.as_str());

    let mut posts = Vec::new();

    for node in document.find(Class("post-preview")).take(10) {
        let title = node.find(Name("h2")).next().unwrap().text();
        let date_str = node.find(Class("post-date")).next().unwrap().text();
        let date = Local.datetime_from_str(date_str.trim(), "%Y-%m-%d %H:%M:%S").unwrap();
        posts.push((date, title));
    }

    posts.sort_by(|a, b| b.0.cmp(&a.0));

    for post in posts {
        println!("{} - {}", post.0.format("%Y-%m-%d %H:%M:%S"), post.1);
    }
}